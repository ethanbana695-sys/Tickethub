const leagues=['Premier League','Championship','League One','League Two','National League','National League North','National League South'];
const seed=[
{home:'Arsenal',away:'Chelsea',league:'Premier League',date:'2026-11-08T16:30',venue:'Emirates Stadium',price:65,stock:120},
{home:'Liverpool',away:'Manchester City',league:'Premier League',date:'2026-11-15T17:30',venue:'Anfield',price:78,stock:80},
{home:'Leeds United',away:'Norwich City',league:'Championship',date:'2026-11-07T15:00',venue:'Elland Road',price:32,stock:150},
{home:'Middlesbrough',away:'Bristol City',league:'Championship',date:'2026-11-14T15:00',venue:'Riverside Stadium',price:27,stock:95},
{home:'Bolton Wanderers',away:'Reading',league:'League One',date:'2026-11-07T15:00',venue:'Toughsheet Community Stadium',price:24,stock:110},
{home:'Huddersfield Town',away:'Wigan Athletic',league:'League One',date:'2026-11-21T15:00',venue:'John Smith’s Stadium',price:22,stock:100},
{home:'Notts County',away:'Walsall',league:'League Two',date:'2026-11-07T15:00',venue:'Meadow Lane',price:19,stock:75},
{home:'Swindon Town',away:'Gillingham',league:'League Two',date:'2026-11-14T15:00',venue:'County Ground',price:18,stock:90},
{home:'York City',away:'Rochdale',league:'National League',date:'2026-11-07T15:00',venue:'York Community Stadium',price:17,stock:60}
];
let matches=JSON.parse(localStorage.getItem('th_matches')||'null')||seed;
let cart=JSON.parse(localStorage.getItem('th_cart')||'[]');
let activeLeague='All';
const $=id=>document.getElementById(id);
function save(){localStorage.setItem('th_matches',JSON.stringify(matches));localStorage.setItem('th_cart',JSON.stringify(cart))}
function money(n){return '£'+Number(n).toFixed(2)}
function dateLabel(s){return new Date(s).toLocaleString('en-GB',{weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}
function renderLeagues(){
 $('leagueChips').innerHTML=['All',...leagues].map(l=>`<button class="chip ${activeLeague===l?'active':''}" data-league="${l}">${l}</button>`).join('');
 $('leagueFilter').innerHTML=['All',...leagues].map(l=>`<option>${l}</option>`).join('');
 $('adminLeague').innerHTML=leagues.map(l=>`<option>${l}</option>`).join('');
 document.querySelectorAll('[data-league]').forEach(b=>b.onclick=()=>{activeLeague=b.dataset.league;$('leagueFilter').value=activeLeague;renderLeagues();renderMatches()});
}
function renderMatches(){
 let list=matches.map((m,i)=>({...m,id:i})).filter(m=>(activeLeague==='All'||m.league===activeLeague)&&(`${m.home} ${m.away}`.toLowerCase().includes($('search').value.toLowerCase()))&&m.stock>0);
 if($('leagueFilter').value!=='All'&&activeLeague==='All')list=list.filter(m=>m.league===$('leagueFilter').value);
 if($('sort').value==='price')list.sort((a,b)=>a.price-b.price);else list.sort((a,b)=>new Date(a.date)-new Date(b.date));
 $('matchGrid').innerHTML=list.length?list.map(m=>`<article class="match-card"><div class="match-meta"><span>${dateLabel(m.date)}</span><span class="league-tag">${m.league}</span></div><div class="teams"><div class="team">${m.home}</div><span class="vs">VS</span><div class="team">${m.away}</div></div><div class="venue">⌖ ${m.venue||'Venue to be confirmed'} · ${m.stock} available</div><div class="card-bottom"><div class="price"><small>Tickets from</small><strong>${money(m.price)}</strong></div><button onclick="addToCart(${m.id})">Find tickets →</button></div></article>`).join(''):'<div class="empty">No matches found. Try another club or league.</div>';
 renderAdmin();
}
function addToCart(id){const m=matches[id];if(!m||m.stock<1)return;let item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});save();renderCart();toast('Added to your basket')}
function renderCart(){let count=cart.reduce((a,x)=>a+x.qty,0),total=0;$('cartCount').textContent=count;
 $('cartItems').innerHTML=cart.length?cart.map(x=>{let m=matches[x.id];if(!m)return '';total+=m.price*x.qty;return `<div class="cart-line"><div><strong>${m.home} v ${m.away}</strong><small>${m.league} · ${dateLabel(m.date)}<br>${money(m.price)} each</small></div><div class="qty"><button onclick="changeQty(${x.id},-1)">−</button>${x.qty}<button onclick="changeQty(${x.id},1)">+</button></div></div>`}).join(''):'<p class="empty">Your basket is empty.</p>';
 $('cartTotal').textContent=money(total)}
function changeQty(id,d){let x=cart.find(x=>x.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(y=>y.id!==id);save();renderCart()}
function renderAdmin(){$('adminRows').innerHTML=matches.map((m,i)=>`<div class="admin-row"><span><b>${m.home} v ${m.away}</b> · ${m.league} · ${money(m.price)} · ${m.stock} left</span><button onclick="removeMatch(${i})">Remove</button></div>`).join('')}
function removeMatch(i){matches.splice(i,1);cart=cart.filter(x=>x.id!==i).map(x=>({...x,id:x.id>i?x.id-1:x.id}));save();renderMatches();renderCart()}
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2100)}
function openCart(open){$('drawer').classList.toggle('open',open);$('backdrop').classList.toggle('hidden',!open)}
$('search').oninput=renderMatches;$('sort').onchange=renderMatches;$('leagueFilter').onchange=()=>{activeLeague='All';renderLeagues();renderMatches()};
$('cartOpen').onclick=()=>openCart(true);$('cartClose').onclick=()=>openCart(false);$('backdrop').onclick=()=>openCart(false);
$('adminToggle').onclick=()=>{$('adminPanel').classList.toggle('hidden');$('adminPanel').scrollIntoView({behavior:'smooth'})};$('closeAdmin').onclick=()=>$('adminPanel').classList.add('hidden');
$('matchForm').onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);matches.push({home:f.get('home'),away:f.get('away'),league:f.get('league'),date:f.get('date'),venue:f.get('venue'),price:Number(f.get('price')),stock:Number(f.get('stock'))});save();e.target.reset();renderMatches();toast('Match listing added')};
$('checkout').onclick=()=>toast('Checkout is a demo. Payment gateway and ticket fulfilment must be connected before taking orders.');
renderLeagues();renderMatches();renderCart();
